# Thrust Controller :leaves:

> Hardware and firmware of the HiDRo thrust controller board.

This board was designed in order to drive an UAM by thrust control.

The repository is made as follow:

- **documentation** folder contains what explain the differente part of the project (component list, how to ...),
- **firmware** folder contains the code to flash the board,
- **hardware** folder contains the Kicad CAD project to manufacture the board.

### More Information

[HiDRo](https://github.com/hidro-iri)
